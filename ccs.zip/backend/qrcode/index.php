<?php
header('Location: http://scce.ustb.edu.cn/');